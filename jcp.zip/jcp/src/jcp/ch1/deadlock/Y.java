package jcp.ch1.deadlock;

public class Y {
	public synchronized void callMe (X x, long sleepTime) {
		String name = Thread.currentThread().getName();
		System.out.println(name + " entered y thread class callMe (X x) method");

		try {
			Thread.sleep(sleepTime);
		} catch (Exception e) {
			System.out.println("Thread Y interrupted");
		}

		System.out.println(name
				+ " attempting to call y thread class's X.hangUp () method");
		x.hangUp();
	}

	public synchronized void hangUp() {
		System.out.println("Inside y thread class's Y.hangUp () method");
	}
}