package jcp.ch1.buffer.v4;

public class SimpleBuffer {
	private final int[] buffer;
	private int currIndex;
	private int head;
	private int tail;

	SimpleBuffer(int capacity) {
		this.buffer = new int[capacity];
		this.currIndex = 0;
		this.head = 0;
		this.tail = 0;
	}

	final synchronized void put(int i) {
		while (isFull()) {
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("InterrupedException caught: "
						+ e.getStackTrace());
			}
		}
		buffer[tail] = i;
		System.out.println(Thread.currentThread().getName() + ": put " + i
				+ " at " + tail);

		if (++tail == buffer.length)
			tail = 0;

		currIndex++;
		notify();
	}

	final synchronized int get() {
		while (isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("InterrupedException caught: "
						+ e.getStackTrace());
			}
		}

		int value = buffer[head];
		System.out.println(Thread.currentThread().getName() + ": get " + value
				+ " at " + head);
		if (++head == buffer.length)
			head = 0;

		--currIndex;
		notify();
		return value;
	}

	final synchronized boolean isFull() {
		return currIndex == buffer.length;
	}

	final synchronized boolean isEmpty() {
		return currIndex == 0;
	}
}