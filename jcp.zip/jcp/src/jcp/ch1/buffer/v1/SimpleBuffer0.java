package jcp.ch1.buffer.v1;

public class SimpleBuffer0 {
	private final int[] buffer;
	private int currIndex;

	SimpleBuffer0(int capacity) {
		this.buffer = new int[capacity];
		this.currIndex = 0;
	}

	final void put(int i) {
		buffer[currIndex++] = i;
	}

	final int get() {
		return buffer[--currIndex];
	}
}
