package jcp.ch1.buffer.v1;

public class SimpleBuffer {
	private final int[] buffer;
	private int currIndex;

	SimpleBuffer(int capacity) {
		this.buffer = new int[capacity];
		this.currIndex = 0;
	}

	final void put(int i) {
		while (isFull()) {
		}
		buffer[currIndex] = i;
		System.out.println(Thread.currentThread().getName() + ": put " + i
				+ " at " + currIndex);
		currIndex++;
	}

	final int get() {
		while (isEmpty()) {
		}

		int value = buffer[--currIndex];
		System.out.println(Thread.currentThread().getName() + ": get " + value
				+ " at " + currIndex);
		return value;
	}

	final boolean isFull() {
		return currIndex == buffer.length;
	}

	final boolean isEmpty() {
		return currIndex == 0;
	}
}
