package jcp.ch1.buffer.v3;

public class Consumer implements Runnable {
	SimpleBuffer simpleBuffer;

	Consumer(SimpleBuffer simpleBuffer) {
		this.simpleBuffer = simpleBuffer;
		new Thread(this, "Consumer").start();
	}

	public void run() {
		while (true) {
			simpleBuffer.get();
		}
	}
}
