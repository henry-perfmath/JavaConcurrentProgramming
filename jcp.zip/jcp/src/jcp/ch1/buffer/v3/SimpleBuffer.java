package jcp.ch1.buffer.v3;

public class SimpleBuffer {
	private final int[] buffer;
	private int currIndex;

	SimpleBuffer(int capacity) {
		this.buffer = new int[capacity];
		this.currIndex = 0;
	}

	final synchronized void put(int i) {
		while (isFull()) {
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("InterrupedException caught: "
						+ e.getStackTrace());
			}
		}
		buffer[currIndex] = i;
		System.out.println(Thread.currentThread().getName() + ": put " + i
				+ " at " + currIndex);
		currIndex++;
		notify();
	}

	final synchronized int get() {
		while (isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				System.out.println("InterrupedException caught: "
						+ e.getStackTrace());
			}
		}

		int value = buffer[--currIndex];
		System.out.println(Thread.currentThread().getName() + ": get " + value
				+ " at " + currIndex);
		notify();
		return value;
	}

	final synchronized boolean isFull() {
		return currIndex == buffer.length;
	}

	final synchronized boolean isEmpty() {
		return currIndex == 0;
	}
}