package jcp.ch1.buffer.v3;

public class SimpleBufferTest {
	public static void main(String args[]) {
		SimpleBuffer simpleBuffer = new SimpleBuffer (10);
		new Producer(simpleBuffer);
		new Consumer(simpleBuffer);
	}
}
