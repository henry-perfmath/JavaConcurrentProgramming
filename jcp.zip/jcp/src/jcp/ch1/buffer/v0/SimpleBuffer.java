package jcp.ch1.buffer.v0;

public class SimpleBuffer {
	private final int[] buffer;
	private int currIndex;

	SimpleBuffer(int capacity) {
		this.buffer = new int[capacity];
		this.currIndex = 0;
	}

	final void put(int i) {
		buffer[currIndex++] = i;
	}

	final int get() {
		return buffer[--currIndex];
	}
}
