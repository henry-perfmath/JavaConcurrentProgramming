package jcp.ch1.buffer.v0;

public class SimpleBufferTest {
	public static void main(String args[]) {

		int capacity = 10;
		SimpleBuffer simpleBuffer = new SimpleBuffer(capacity);

		System.out.print("SimpleBuffer: put");
		for (int i = 0; i < capacity; i++) {
			simpleBuffer.put(i);
			System.out.print(" " + i);
		}

		System.out.print("\nSimpleBuffer: get");
		for (int i = 0; i < capacity; i++) {
			System.out.print(" " + simpleBuffer.get());
		}
		System.out.print("\ndone");
	}
}