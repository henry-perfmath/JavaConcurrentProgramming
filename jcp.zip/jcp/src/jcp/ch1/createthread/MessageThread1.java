package jcp.ch1.createthread;

class MessageThread1 implements Runnable {
	String msg;
	Messager1 target;
	Thread t;

	public MessageThread1(Messager1 targ, String s) {
		target = targ;
		msg = s;
		t = new Thread(this);
		t.start();
	}

	public void run() {
		synchronized (target) { // synchronized block
			target.sendMessage(msg);
		}
	}
}
