package jcp.ch1.createthread;

public class ExtendedThread extends Thread {
	ExtendedThread() {
		// Create a new thread
		super("ExtendedThread");
		System.out.println("Child thread: " + this);
		start(); // Start the thread in the constructor
	}

	// The run method for the new thread.
	public void run() {
		try {
			for (int i = 3; i > 0; i--) {
				System.out.println("Child Thread: " + i);
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			System.out.println("Child interrupted.");
		}
		System.out.println("Exiting child thread.");
	}
}

