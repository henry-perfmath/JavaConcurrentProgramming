package jcp.ch1.createthread;

class NewThread implements Runnable {
	Thread t;

	NewThread() {
		// Create a new thread
		t = new Thread(this, "New Thread");
		System.out.println("Child thread: " + t);
		t.start(); // Start the new thread from the constructor
	}

	// The run method for the new thread.
	public void run() {
		try {
			for (int i = 3; i > 0; i--) {
				System.out.println("Child Thread: " + i);
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			System.out.println("Child interrupted.");
		}
		System.out.println("Exiting child thread.");
	}
}
