package jcp.ch6.synchronizers;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

public class SemaphoreDemo {
	public static void main(String[] args) throws InterruptedException {
		Semaphore semaphore = new Semaphore(1);
		int POOL_SIZE = 3;
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 2. launch 3 counters
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new Counter(i, semaphore));
		}

		// 3. wait 5000 ms for all drawers to complete
		Thread.sleep(5000);
		System.out.println("Shared.count = " + Shared.count);

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

// Thread class: Counter increments/decrements count five times if id is
// even/odd.
class Counter extends Thread {
	int id;
	Semaphore semaphore;

	Counter(int id, Semaphore semaphore) {
		this.id = id;
		this.semaphore = semaphore;
	}

	public void run() {
		try {
			semaphore.acquire();
			for (int i = 0; i < 5; i++) {
				if ((this.id % 2) == 0) {
					Shared.count++;
					System.out.println("thread " + id + ": " + Shared.count);
				} else {
					Shared.count--;
					System.out.println("thread " + id + ": " + Shared.count);
				}
			}
		} catch (InterruptedException ie) {
			System.out.println("interrupted");
		} finally {
			semaphore.release();
		}
	}
}

// Shared resource:
class Shared {
	static int count = 0;
}
