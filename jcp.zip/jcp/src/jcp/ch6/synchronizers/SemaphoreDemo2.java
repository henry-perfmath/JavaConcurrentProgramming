package jcp.ch6.synchronizers;

public class SemaphoreDemo2 {
	public static void main(String args[]) {
		Buffer buffer = new Buffer();
		new Producer(buffer);
		new Consumer(buffer);
	}
}

class Consumer implements Runnable {
	private Buffer buffer;
	Consumer(Buffer buffer) {
		this.buffer = buffer;
		new Thread(this, "Consumer").start();
	}

	public void run() {
		while (true) {
			buffer.get();
		}
	}
}

class Producer implements Runnable {
	private Buffer buffer;
	Producer(Buffer buffer) {
		this.buffer = buffer;
		new Thread(this, "Producer").start();
	}

	public void run() {
		int i = 0;
		while (true) {
			buffer.put(i++);
		}
	}
}
