package jcp.ch6.synchronizers;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchDemo {
	public static void main(String args[]) {

		// 1. create the latch
		int EVENT_COUNT = 3;
		CountDownLatch latch = new CountDownLatch(EVENT_COUNT);

		// 2. pass latch to the latch thread
		new LatchThread(latch);

		// 3. wait
		try {
			latch.await();
		} catch (InterruptedException ie) {
			System.out.println(ie);
		}

		// 4. done
		System.out.println("done");
	}
}

class LatchThread implements Runnable {
	CountDownLatch latch;
	long count;

	LatchThread(CountDownLatch latch) {
		this.latch = latch;
		count = latch.getCount();
		new Thread(this).start();
	}

	public void run() {
		for (int i = 0; i < count; i++) {
			System.out.println("LatchThread counting down: " + i);
			latch.countDown();
		}
	}
}