package jcp.ch6.synchronizers;

import java.util.concurrent.Semaphore;

public class Buffer {
	final Semaphore semaCon = new Semaphore(0);
	final Semaphore semaProd = new Semaphore(1);
	int buffer;

	public void put(int n) {
		try {
			semaProd.acquire();
		} catch (InterruptedException ie) {
			System.out.println("Interrupted");
		}
		this.buffer = n % 100;
		System.out.println("buffer put: " + buffer);
		semaCon.release();
	}

	public void get() {
		try {
			semaCon.acquire();
		} catch (InterruptedException ie) {
			System.out.println("Interrupted");
		}
		System.out.println("buffer get: " + buffer);
		semaProd.release();
	}
}
