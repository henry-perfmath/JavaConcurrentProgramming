package jcp.ch2.executorservice.example3;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SimpleESDemo3 {
	public static void main(String args[]) {
		ExecutorService executorService = Executors.newSingleThreadExecutor();

		Set<Callable<String>> callables = new HashSet<Callable<String>>();

		callables.add(new Callable<String>() {
			public String call() throws Exception {
				Thread.currentThread().stop();
				return "task 1 succeeded";
			}
		});
		callables.add(new Callable<String>() {
			public String call() throws Exception {
				Thread.currentThread().stop();
				return "task 2 succeeded";
			}
		});
		callables.add(new Callable<String>() {
			public String call() throws Exception {
				Thread.currentThread().stop();
				return "task 3 succeeded";
			}
		});

		String result = "";
		try {
			result = executorService.invokeAny(callables);
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}

		System.out.println("result = " + result);
		executorService.shutdown();
	}
}
