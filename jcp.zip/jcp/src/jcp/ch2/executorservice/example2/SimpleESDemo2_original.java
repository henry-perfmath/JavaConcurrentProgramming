package jcp.ch2.executorservice.example2;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

public class SimpleESDemo2_original {
	public static void main(String args[]) {
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors.newFixedThreadPool(5);

		// 2. Execute an anonymous thread/task asynchronously
		Future future = executorService.submit(new Callable() {
			public Object call () throws Exception {
				return computeFactorial(Thread.currentThread().getName());
			}
		});
		
		try {		
			System.out.println ("future.get () = " + future.get () + 
				" (resulted in factorial integer overflow)");
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		// 3. shut down executorService to avoid resource leak
		executorService.shutdown();
	}

	public static int computeFactorial(String name) {
		int count = -1;
		int result = 1;

		do {
			count++;
			result = factorial(count);
			System.out.println(Thread.currentThread().getName() + ": count = "
					+ count + " factorial = " + result);
		} while (result > 0);
		return count;
	}

	public static int factorial(int n) {
		if (n == 0) {
			return 1;
		} else {
			return n * factorial(n - 1);
		}
	}
}
