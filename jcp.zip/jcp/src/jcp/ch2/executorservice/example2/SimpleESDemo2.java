package jcp.ch2.executorservice.example2;

import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SimpleESDemo2 {
	public static void main(String args[]) {
		int POOL_SIZE = 5;
		int TASK_SIZE = POOL_SIZE + 1;
		
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 2. Create a Future array with the given task size
		Future<String>[] futures = new Future[TASK_SIZE];
		
		// 3. Submit anonymous Factorial tasks asynchronously
		Random random = new Random();
		for (int i = 0; i < TASK_SIZE; i++) {
			int countMax = random.nextInt(10);
			futures[i] = executorService.submit(new Factorial (i, countMax));
		}
		
		// 4. check result
		try {
			for (int i = 0; i < TASK_SIZE; i++) {
				System.out.println("future get: " + futures[i].get());
			}
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
		
		// 5. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

class Factorial implements Callable<String> {
	int id;
	int countMax;

	Factorial(int id, int countMax) {
		this.id = id;
		this.countMax = countMax;
	}

	public String call() throws Exception {
		return computeFactorial(Thread.currentThread().getName());
	}

	public String computeFactorial(String name) {
		int count = -1;
		int result = 1;

		do {
			count++;
			result = factorial(count);
		} while (count < this.countMax);

		System.out.println(Thread.currentThread().getName() + ": count = "
				+ count + " factorial = " + result);
		return "count = " + count + " factorial = " + result;
	}

	public int factorial(int n) {
		if (n == 0) {
			return 1;
		} else {
			return n * factorial(n - 1);
		}
	}
}