package jcp.ch4.atomic;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// test driver
public class AtomicIntegerDemo {

	public static void main(String[] args) throws InterruptedException {

		final Permit permit = new Permit();
		permit.setPermits (9);
		
		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors.newFixedThreadPool(100);

		// 2. launch 100 drawers
		for (int i = 0; i < 100; i++) {
			executorService.execute (new Drawer (i, permit));
		}

		// 3. wait 5000 ms for all drawers to complete
		Thread.sleep(5000);
		System.out.println("Number of permits: " + permit.getPermits());
		
		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

// Thread class: a drawer increments/decrements permits if id is even/odd.
class Drawer extends Thread {
	int id;
	Permit permit;

	Drawer(int id, Permit permit){
		this.id = id;
		this.permit = permit;
	}
	public void run() {
		for (int i = 0; i < 10000; i++) {
			if ((this.id % 2) == 0) {
				permit.incrementPermits();
			} else {
				permit.decrementPermits();
			}
		}
	}
}

// Shared resource: AtomicInteger synchronizes permits
class Permit {

	private AtomicInteger permits = new AtomicInteger(0);

	public int getPermits() {
		return permits.get();
	}
	
	public void setPermits(int newValue) {
		permits.set(newValue);
	}
	
	public void incrementPermits() {
		permits.incrementAndGet();
	}
	
	public void decrementPermits() {
		permits.decrementAndGet();
	}
}
