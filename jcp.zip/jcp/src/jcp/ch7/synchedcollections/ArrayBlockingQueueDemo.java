package jcp.ch7.synchedcollections;

import java.util.concurrent.ArrayBlockingQueue;

public class ArrayBlockingQueueDemo {
	public static void main(String args[]) {

		ArrayBlockingQueue<Integer> arrayBlockingQueue = new ArrayBlockingQueue<Integer>(
				8, true);
		new Producer(arrayBlockingQueue);
		new Consumer(arrayBlockingQueue);
	}
}

class Consumer implements Runnable {
	private ArrayBlockingQueue<Integer> arrayBlockingQueue;

	Consumer(ArrayBlockingQueue<Integer> arrayBlockingQueue) {
		this.arrayBlockingQueue = arrayBlockingQueue;
		new Thread(this, "Consumer").start();
	}

	public void run() {
		while (true) {
			try {
				int number = (Integer) arrayBlockingQueue.take();
				System.out.println("consumer got " + number);
			} catch (InterruptedException ie) {
				System.out.println("consumer interrupted");
			}
		}
	}
}

class Producer implements Runnable {
	ArrayBlockingQueue<Integer> arrayBlockingQueue;

	Producer(ArrayBlockingQueue<Integer> arrayBlockingQueue) {
		this.arrayBlockingQueue = arrayBlockingQueue;
		new Thread(this, "Producer").start();
	}

	public void run() {
		int i = 0;

		while (true) {
			try {
				arrayBlockingQueue.put(new Integer(i));
				System.out.println("producer put " + i);
				i++;
			} catch (InterruptedException ie) {
				System.out.println("producer interrupted");
			}
		}
	}
}