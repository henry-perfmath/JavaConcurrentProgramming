package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class WorkerThread2 extends Thread {
	int id;
	Random random;
	ConcurrentLinkedDeque<String> concurrentLinkedDeque;

	WorkerThread2(int id, ConcurrentLinkedDeque<String> concurrentLinkedDeque) {
		this.id = id;
		this.random = new Random();
		this.concurrentLinkedDeque = concurrentLinkedDeque;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			String item = id + "_" + random.nextInt(IMAX);
			boolean output = (i % (IMAX / 10)) == 0;
			if ((id % 2) == 0) {
				concurrentLinkedDeque.add(item);
				if (output)
					System.out.println ("Thread " + id + " add: " + item);
			} else {
				String value = concurrentLinkedDeque.poll();
				if (output)
					System.out.println ("Thread " + id + " poll: " + value);
			}
		}
	}
}

public class ConcurrentLinkedDequeDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;
		
		// 1. create a concurrent linked deque
		ConcurrentLinkedDeque<String> concurrentLinkedDeque = 
				new ConcurrentLinkedDeque<String> ();

		// 2. create a newFixedThreadPool using the ExecutorService class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 3. launch worker threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new WorkerThread2(i, concurrentLinkedDeque));
		}

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
		
		// 5. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println ("size = " + concurrentLinkedDeque.size());
	}
}
