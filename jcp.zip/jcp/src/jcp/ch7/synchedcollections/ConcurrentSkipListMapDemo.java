package jcp.ch7.synchedcollections;

import java.util.Iterator;
import java.util.NavigableSet;
import java.util.Random;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class SkipListMapper extends Thread {
	int id;
	Random random;
	ConcurrentSkipListMap<Integer, String> concurrentSkipListHashMap;

	SkipListMapper(int id, ConcurrentSkipListMap<Integer, String> concurrentSkipListHashMap) {
		this.id = id;
		this.random = new Random();
		this.concurrentSkipListHashMap = concurrentSkipListHashMap;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			Integer key = random.nextInt(IMAX);
			String value = id + "_" + key;
			boolean output = (i % (IMAX / 10)) == 0;
			if ((id % 4) == 0) {
				concurrentSkipListHashMap.put(key, value);
				if (output)
					System.out.println ("Thread " + id + " put: " + key + " - >" + value);
			} else {
				String val = concurrentSkipListHashMap.get(key);
				if (output)
					System.out.println ("Thread " + id + " get: " + key + " -> " + val);
			}
		}
	}
}

public class ConcurrentSkipListMapDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;
		ConcurrentSkipListMap<Integer, String> concurrentSkipListMap = 
				new ConcurrentSkipListMap<Integer, String> ();

		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 2. launch skip list mapper threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new SkipListMapper(i, concurrentSkipListMap));
		}

		// 3. shut down executorService to avoid resource leak
		executorService.shutdown();
		
		// 4. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println ("size = " + concurrentSkipListMap.size());
		
		// 5. check ketSet, subMap, headMap and tailMap
		System.out.println ("\ncall checkKeySet: ");
		checkKeySet (concurrentSkipListMap);
		
		System.out.println ("\ncall checkSubMap: ");
		checkSubMap (concurrentSkipListMap);
		
		System.out.println ("\ncall checkHeadMap: ");
		checkHeadMap (concurrentSkipListMap);
		
		System.out.println ("\ncall checkTailMap: ");
		checkTailMap (concurrentSkipListMap);
	}
	
	public static void checkKeySet (ConcurrentSkipListMap<Integer, String> concurrentSkipListMap) {
		
		NavigableSet<Integer> navigableKeySet = concurrentSkipListMap.keySet();
		Iterator<Integer> iterator = navigableKeySet.iterator();
		int i = 0;
		while (i < 5 && iterator.hasNext()) {
			Integer key = iterator.next();
			String value = concurrentSkipListMap.get(key);
			System.out.println("key = " + key + " value = " + value); 
			i++;
		}
	}
	
	public static void checkSubMap (ConcurrentSkipListMap<Integer, String> concurrentSkipListMap) {
		ConcurrentNavigableMap<Integer, String> subMap = concurrentSkipListMap.subMap(20, 50); 
		printMap (subMap);
	}
		
	public static void checkHeadMap (ConcurrentSkipListMap<Integer, String> concurrentSkipListMap) {
		ConcurrentNavigableMap<Integer,String> headMap = concurrentSkipListMap.headMap(5); 
		printMap (headMap);
	}

	public static void checkTailMap (ConcurrentSkipListMap<Integer, String> concurrentSkipListMap) {
		ConcurrentNavigableMap<Integer,String> tailMap = concurrentSkipListMap.tailMap(100); 
		printMap (tailMap);
	}
	
	public static void printMap (ConcurrentNavigableMap<Integer,String> map) {
		NavigableSet<Integer> navigableKeySet = map.keySet();
		Iterator<Integer> iterator = navigableKeySet.iterator();
		int i = 0;
		while (i < 5 && iterator.hasNext()) {
			Integer key = iterator.next();
			String value = map.get(key);
			System.out.println("key = " + key + " value = " + value); 
			i++;
		}
	}
}