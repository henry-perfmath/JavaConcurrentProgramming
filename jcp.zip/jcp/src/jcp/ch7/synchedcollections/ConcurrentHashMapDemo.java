package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class Mapper extends Thread {
	int id;
	Random random;
	ConcurrentHashMap<Integer, String> concurrentHashMap;

	Mapper(int id, ConcurrentHashMap<Integer, String> concurrentHashMap) {
		this.id = id;
		this.random = new Random();
		this.concurrentHashMap = concurrentHashMap;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			Integer key = random.nextInt(IMAX);
			String value = id + "_" + key;
			boolean output = (i % (IMAX / 10)) == 0;
			if ((id % 4) == 0) {
				concurrentHashMap.put(key, value);
				if (output)
					System.out.println ("Thread " + id + " put: " + key + "->" + value);
			} else {
				String val = concurrentHashMap.get(key);
				if (output)
					System.out.println ("Thread " + id + " get: " + key + "->" + val);
			}
		}
	}
}

public class ConcurrentHashMapDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;
		ConcurrentHashMap<Integer, String> concurrentHashMap = 
				new ConcurrentHashMap<Integer, String> (20000, 0.75f, POOL_SIZE);

		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 2. launch schedulers
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new Mapper(i, concurrentHashMap));
		}

		// 3. shut down executorService to avoid resource leak
		executorService.shutdown();
		
		// 4. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println ("size = " + concurrentHashMap.size());
	}
}
