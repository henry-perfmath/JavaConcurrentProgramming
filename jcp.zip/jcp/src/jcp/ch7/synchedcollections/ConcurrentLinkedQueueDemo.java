package jcp.ch7.synchedcollections;

import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class WorkerThread extends Thread {
	int id;
	Random random;
	ConcurrentLinkedQueue<String> concurrentLinkedQueue;

	WorkerThread(int id, ConcurrentLinkedQueue<String> concurrentLinkedQueue) {
		this.id = id;
		this.random = new Random();
		this.concurrentLinkedQueue = concurrentLinkedQueue;
	}

	public void run() {
		int IMAX = 10000;
		for (int i = 0; i < IMAX; i++) {
			String item = id + "_" + random.nextInt(IMAX);
			boolean output = (i % (IMAX / 10)) == 0;
			if ((id % 2) == 0) {
				concurrentLinkedQueue.add(item);
				if (output)
					System.out.println ("Thread " + id + " add: " + item);
			} else {
				String value = concurrentLinkedQueue.poll();
				if (output)
					System.out.println ("Thread " + id + " poll: " + value);
			}
		}
	}
}

public class ConcurrentLinkedQueueDemo {

	public static void main(String[] args) {

		int POOL_SIZE = 8;
		
		// 1. create a concurrent linked queue
		ConcurrentLinkedQueue<String> concurrentLinkedQueue = 
				new ConcurrentLinkedQueue<String> ();

		// 2. create a newFixedThreadPool using the ExecutorService class
		ExecutorService executorService = Executors
				.newFixedThreadPool(POOL_SIZE);

		// 3. launch worker threads
		for (int i = 0; i < POOL_SIZE; i++) {
			executorService.execute(new WorkerThread(i, concurrentLinkedQueue));
		}

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
		
		// 5. wait until all threads are done
		try {
			executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println ("size = " + concurrentLinkedQueue.size());
	}
}
