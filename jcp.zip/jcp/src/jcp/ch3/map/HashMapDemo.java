package jcp.ch3.map;
import java.util.*;

public class HashMapDemo {
	public static void main (String args[]) {
		// 1. create a hash map
		HashMap<String, String> hashMap = new HashMap<String, String> ();
		
		// 2. put key-value pairs to the map
		hashMap.put("Virginia", "VA");
		hashMap.put("Washington", "WA");
		hashMap.put("California", "CA");
		hashMap.put("Distric of Columbia", "DC");
		hashMap.put("Massachusetts", "MA");
		hashMap.put("New Jersey", "NJ");
		
		// 3. get map's entrySet
		Set<Map.Entry<String, String>> set = hashMap.entrySet();
		
		// 4. Display the entry set
		for (Map.Entry<String, String> entry : set) {
			System.out.print (entry.getKey() + ": ");
			System.out.println (entry.getValue());
		}
		
		// 5. get state abbreviation by key
		String caAbbr = hashMap.get("California");
		System.out.println ("state abbreviation for California: " + caAbbr);
	}
}
