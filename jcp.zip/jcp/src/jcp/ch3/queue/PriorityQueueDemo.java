package jcp.ch3.queue;
import java.util.*;

public class PriorityQueueDemo {

	public static void main(String[] args) {
		int[] priorities = { 2, 9, 1, 3, 1, 8, 7, 0, 5 };
		System.out.println("priority input = " + "[2, 9, 1, 3, 1, 8, 7, 0, 5]");
		PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
 
		// add elements to pq using offer() method
		for (int p : priorities) {
			pq.offer(p);
		}
		
		// print queue and size
		System.out.println("original pq = " + pq + " (size = " + pq.size() + ")");

		// peek the highest priority
		System.out.println("after peek: " + pq.peek() + ", pq = " + pq + 
				" (size = " + pq.size() + ")");
		
		// return highest priority and remove it from the queue
		System.out.println("after poll: " + pq.poll() + ", pq = " + pq + 
				" (size = " + pq.size() + ")");
	}
}