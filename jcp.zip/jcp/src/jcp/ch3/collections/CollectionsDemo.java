package jcp.ch3.collections;

import java.util.ArrayList;
import java.util.Collections;

public class CollectionsDemo {
	public static void main (String args[]) {
		// create an ArrayList collection
		ArrayList<String> al = new ArrayList ();

		// add elements
		al.add ("This ");
		al.add ("is ");
		al.add ("an ");
		al.add ("ArrayList ");
		al.add ("demo");
		System.out.println (al);	
		
		boolean success = Collections.addAll(al, "with ", "addAll ", "algorithm ", "applied");
		if (success) {
			System.out.println (al);
		} else {
			System.out.println ("Collections.addAll failed");
		}
	}
}
