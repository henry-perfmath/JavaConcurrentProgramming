package jcp.ch3.set;
import java.util.*;

public class LinkedHashSetDemo {
	public static void main (String args[]) {
		// create a linked hash set
		HashSet<String> lhs = new LinkedHashSet<String> ();
		
		// add elements
		lhs.add ("This ");
		lhs.add ("is ");
		lhs.add (" a");
		lhs.add (" HashSet ");
		lhs.add ("demo");
		System.out.println (lhs);
		System.out.println (lhs.toString ());
	}
}
