package jcp.ch3.algorithms;

import java.util.*;

public class AsLifoQueueDemo {
	public static void main(String args[]) {

		// 1. create, populate and print the array deque
		Deque<String> arrayDeque = new ArrayDeque<String>();
		arrayDeque.add("a");
		arrayDeque.add("b");
		arrayDeque.add("c");
		arrayDeque.add("d");
		System.out.println("Original deque is: " + arrayDeque);
		System.out.println("original deque peek: " + arrayDeque.peek());

		// 2. return a view of the array deque as a LIFO queue
		Queue<String> queue = Collections.asLifoQueue(arrayDeque);
		System.out.println("Returned queue is: " + queue);
		System.out.println("Returned queue peek: " + queue.peek() + "\n");

		// 3. test LIFO
		queue.add("test1");
		System.out.println("Returned queue is: " + queue);
		System.out.println("Returned queue is: " + queue.peek());

		// 4. test LIFO again
		queue.add("test2");
		System.out.println("Returned queue is: " + queue);
		System.out.println("Returned queue is: " + queue.peek());
	}
}
