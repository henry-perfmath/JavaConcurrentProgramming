package jcp.ch3.algorithms;
import java.util.*;

public class CheckedSetDemo {

	public static void main(String a[]) {

		Set hashSet = new HashSet ();

		hashSet.add("One");
		hashSet.add("Two");
		System.out.println("Initial unchecked hash set: " + hashSet);

		// unchecked allows any type of elements to be added
		hashSet.add(3);
		System.out.println("Modified unchecked hash set: " + hashSet);

		Set checkedHashSet = Collections.checkedSet(hashSet, String.class);
		System.out.println("Initial checked hash set: " + checkedHashSet);

		// adding incompatible type of elements to a checked collection
		// throws ClassCastException
		checkedHashSet.add(3);
		System.out.println("Modified checked hash set: " + checkedHashSet);
	}
}