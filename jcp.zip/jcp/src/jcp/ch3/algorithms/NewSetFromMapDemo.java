package jcp.ch3.algorithms;
import java.util.*;

public class NewSetFromMapDemo {
	public static void main(String args[]) {
		// 1. create a hash map
		WeakHashMap<String, Boolean> weakHashMap = new WeakHashMap<String, Boolean>();
		System.out.println("Initial Map: " + weakHashMap);
		
		// 2. create a new set from map
		Set<String> weakHashSet = Collections.newSetFromMap(weakHashMap);

		// 3. add entries to set
		weakHashSet.add("Java");
		weakHashSet.add("and");
		weakHashSet.add("C#");
		
		// 4. set and map values are
		System.out.println("New Set: " + weakHashSet);
		System.out.println("Map: " + weakHashMap);
	}
}
