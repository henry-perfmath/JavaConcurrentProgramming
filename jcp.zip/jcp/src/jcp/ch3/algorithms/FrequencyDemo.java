package jcp.ch3.algorithms;
import java.util.*;

public class FrequencyDemo {
	public static void main(String args[]) {
		
		// 1. creating an ArrayList
		List<String> arrayList = new ArrayList<String>();

		// 2. populating the ArrayList
		arrayList.add("no"); arrayList.add("bird");
		arrayList.add("soars"); arrayList.add("too");
		arrayList.add("high"); arrayList.add("if"); 
		arrayList.add("he"); arrayList.add("soars"); 
		arrayList.add("with"); arrayList.add("his"); 
		arrayList.add("own"); arrayList.add("wings");
		System.out.println(arrayList.toString());
		
		// 3. getting frequency of 'soars'
		int freq = Collections.frequency(arrayList, "soars");
		System.out.println("Frequency of 'soars' is: " + freq);
	}
}