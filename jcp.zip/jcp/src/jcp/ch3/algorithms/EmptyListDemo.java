package jcp.ch3.algorithms;
import java.util.*;

public class EmptyListDemo {
	public static void main(String args[]) {
		// 1. create an empty list
		List<String> emptyList = Collections.emptyList();
		System.out.println("Created an empty immutable list: " + emptyList);

		// 2. add elements. Expect an exception
		emptyList.add("x");
	}
}