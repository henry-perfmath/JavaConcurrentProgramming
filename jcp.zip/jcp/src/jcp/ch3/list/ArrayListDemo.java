package jcp.ch3.list;
import java.util.*;

public class ArrayListDemo {
	public static void main (String args[]) {
		// create an ArrayList collection
		ArrayList<String> al = new ArrayList ();
		System.out.println ("Initial size of al: " + al.size());
		
		// add elements
		al.add ("This ");
		al.add ("is ");
		al.add ("an ");
		al.add ("ArrayList ");
		al.add ("demo");
		System.out.println (al);	
		System.out.println ("Size after adding 5 elements: " + al.size());
		System.out.println ("Index for the \"simple \" string: " + al.indexOf ("simple "));
		
		// add an element at index = 3
		al.add(3, "simple ");
		System.out.println (al);	
		System.out.println ("Size after adding an element at index = 3: " + al.size());
		
		// add an element at index = 5
		al.add(5, "simple ");
		System.out.println (al);	
		System.out.println ("Size after adding an element at index = 5 again: " + al.size());
		
		// indexOf and lastIndexOf
		System.out.println ("Index for the \"simple \" string: " + al.indexOf ("simple "));
		System.out.println ("Index for the last \"simple \" string: " + al.lastIndexOf ("simple "));
		// remove the "simple" string
		al.remove("simple ");
		System.out.println (al);	
		System.out.println ("Size after removing an element: " + al.size());
	}
}
