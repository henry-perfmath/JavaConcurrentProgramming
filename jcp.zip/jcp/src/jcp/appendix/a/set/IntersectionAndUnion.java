package jcp.appendix.a.set;

import java.util.ArrayList;

public class IntersectionAndUnion {

	// use merge since two arrays already sorted
	public static ArrayList<Integer> getIntersection(int[] a, int[] b) {

		int n = a.length;
		int m = b.length;
		ArrayList<Integer> c = new ArrayList<Integer> (n);
		
		int i = 0;
		int j = 0;
		
		while ((i < n) && (j < m)) {
			if (a[i] < b [j]) {
				i++;
			} else if (a[i] > b [j]) {
				j++;
			} else {
				c.add (a [i]);
				i++;
				j++;
			}
		}
		return c;
	}

	// use merge since two arrays already sorted
	public static ArrayList<Integer> getUnion(int[] a, int[] b) {

		int n = a.length;
		int m = b.length;

		ArrayList<Integer> c = new ArrayList<Integer> (n);
		int i = 0;
		int j = 0;
		
		while ((i < n) && (j < m)) {
			if (a[i] == b [j]) {
				c.add (a [i++]);
				j++;
			} else {
				c.add (a[i++]);
				c.add (b[j++]);
				/*
				if (a [i] < b [j]) {
					c.add (a[i++]);
				} else {
					c.add (b[j++]);
				}
				*/
			}
		}
		
		// process leftovers
		while (i < n) {
			c.add (a[i++]);
		}
		
		while (j < m) {
			c.add (a[j++]);
		}
		return c;
	}
	
	public static void main(String[] args) {
		int[] a = { 1, 3, 5, 8, 18, 20 };
		int[] b = { 2, 5, 6, 8, 15, 18 };

		System.out.println ("Testing intersection:");
		ArrayList<Integer> c = getIntersection(a, b);
		for (Integer i: c) {
			System.out.print (i.intValue() + " ");
		}
		
		System.out.println ("\nTesting union:");
		ArrayList<Integer> u = getUnion (a, b);
		for (Integer i: u) {
			System.out.print (i.intValue() + " ");
		}
	}
}
