package jcp.appendix.a.linked.list;

public class SinglyLinkedListTest {

	public static void main(String[] args) {
		SinglyLinkedList list = new SinglyLinkedList ();
		 
		list.insert (10);
		list.insert (15);
		list.insert(20);
		list.printList ();
		System.out.println ("Test reverse");
		list.reverse ();
		list.printList ();

	}

}
