package jcp.appendix.a.linked.list;

public class LinkedList {
	ListNode first;
	ListNode last;
	int size;
	
	LinkedList () {
		size = 0;
		first = null;
		last = null;
	}
	
	public void addFirst (int data) {
		ListNode newNode = new ListNode (data);
		
		if (size == 0) {
			first = last = newNode;
		} else {
			newNode.setNext(first);
			first = newNode;
		}

		size++;
	}
	public void addLast (int data) {
		ListNode newNode = new ListNode (data);
		if (size == 0) {
			first = last = newNode;
		} else {
			last.setNext(newNode);
			last = newNode;
		}

		size++;
	}
	
	public int getFirst () {
		return first.getData();
	}
	
	public int getLast () {
		return last.getData();
	}
	
	public void removeFirst () {
		if (first != null) {
			ListNode temp = first;
			first = first.getNext ();
			temp = null;
			size--;
		}
	}
	public void removeLast () {
		if (last != null) {
			ListNode node = first;
			while (node.getNext () != last) {
				node = node.getNext();
			}
			last = node;
			last.setNext (null);	
			size--;
		}
	}
	
	public int get (int position) {
		if (position >= 0 && position < size) {
			ListNode node = first;

			for (int i = 0; i < position; i++) {
				node = node.getNext();
			}
			return node.getData();
		} else {
			System.out.println("out of range");
			return -1;
		}
	}
	
	public void fold (int position) {
		// find the node at this position
		ListNode node = first;
		for (int i = 0; i < position; i++) {
			node = node.getNext ();
		}
		last.setNext(node);
	}
}
