package jcp.appendix.a.bst;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

class BSTNode {
	int value;
	BSTNode left, right;
	
	public BSTNode () {
		value = 0;
		left = right = null;
	}
	public BSTNode (int value) {
		this.value = value;
		left = right = null;
	}
	public BSTNode(int value, BSTNode left, BSTNode right) {
		this.value = value;
		this.left = left;
		this.right = right;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public BSTNode getLeft() {
		return left;
	}
	public void setLeft(BSTNode left) {
		this.left = left;
	}
	public BSTNode getRight() {
		return right;
	}
	public void setRight(BSTNode right) {
		this.right = right;
	}
}

class BST {
	private BSTNode root;
	public BST () {
		root = null;
	}
	
	public boolean isEmpty () {
		return root == null;
	}
	
	public void insert (int value) {
		root = insert (root, value);
	}
	
	// returns the new node inserted
	// recursive
	// allows inserting duplicate value
	private BSTNode insert (BSTNode node, int value) {
		if (node == null) {
			node = new BSTNode (value);
		} else {
			if (value <= node.getValue()) { // "=" goes to left
				node.left = insert (node.left, value);
			} else {
				node.right = insert (node.right, value);
			}
		}
		return node;
	}
	
	public void delete (int value) {
		if (isEmpty()) {
			System.out.println ("tree empty");
		} else if (search (value) == false) {
			System.out.println ("value " + value + " does not exist");
		} else {
			root = delete (root, value);
			System.out.println (value + " deleted");
		}
	}
	
	private BSTNode delete (BSTNode root, int value) {
		BSTNode leftMostLeaf, newRoot, n;
		if (root.getValue () == value) { // delete root
			BSTNode left, right; // current left and right
			left = root.getLeft();
			right = root.getRight();
			if (left == null && right == null) { // single root node
				return null;
			} else if (left == null) { // no left subtree
				return right;
				//p = right;
				//return p;
			} else if (right == null) { // no right subtree
				//p = left;
				//return p;
				return left;
			} else { // has left and right subtrees. find leftMostLeaf
				newRoot = right;
				leftMostLeaf = right;
				while (leftMostLeaf.getLeft () != null) {
					leftMostLeaf = leftMostLeaf.getLeft();
				}
				leftMostLeaf.setLeft(left); // attach original left subtree to leftMostLeaf
				return newRoot;
			}
		}
		
		if (value < root.getValue ()) { // value is at left
			n = delete (root.getLeft(), value);
			root.setLeft(n);
		} else { // value is at right
			n = delete (root.getRight(), value);
			root.setRight(n);
		}
		return root;
	}
	
	public int countNodes () {
		return countNodes (root);
	}
	
	private int countNodes (BSTNode node) {
		if (node == null) {
			return 0;
		} else {
			int count = 1;
			count += countNodes (node.getLeft());
			count += countNodes (node.getRight());
			return count;
		}
	}
	// return BSTNode found rather than a boolean? 
	// recursive requires found in the while loop
	public boolean search (int value) {
		return search (root, value);
	}
	
	private boolean search (BSTNode node, int value) {
		boolean found = false;
		while ((node != null) && !found) { // keep searching if node not null and not found
			int nodeValue = node.getValue();
			if (value < nodeValue) {
				node = node.getLeft ();
			} else if (value > nodeValue) {
				node = node.getRight();
			} else {
				found = true;
				System.out.println ("found value " + value + " who has " +
						(countNodes (node) - 1) + " children");
				break;
			}
			found = search (node, value); // recursive
		}
		return found;
	}
	
	public void preOrder () {
		preOrder (root);
	}
	
	private void preOrder (BSTNode node) {
		if (node != null) {
			System.out.print (node.getValue() + " ");
			preOrder (node.getLeft());
			preOrder (node.getRight());
		}
	}
	// inorder and postorder are depth-first traversals
	public void inOrder () {
		inOrder (root);
	}
	
	private void inOrder (BSTNode node) {
		if (node != null) {
			inOrder (node.getLeft());
			System.out.print (node.getValue() + " ");
			inOrder (node.getRight());
		}
	}
	
	public void postOrder () {
		postOrder (root);
	}
	private void postOrder (BSTNode node) {
		if (node != null) {
			postOrder (node.getLeft());
			postOrder (node.getRight());
			System.out.print (node.getValue() + " ");
		}
	}
	public void breadthFirst () {
		Queue<BSTNode> q = new LinkedList<BSTNode> ();
		BSTNode node;
		
		if (root != null) {
			q.add (root); // add to the end of the list
			
			while (!q.isEmpty()) {
				node = (BSTNode) q.remove(); // remove the head and print it
				System.out.print (node.getValue() + " ");
				
				// after the left is removed, right sibling will be the next
				// because right sibling is added following the left sibling
				
				if ( node != null ) {
					if (node.getLeft() != null) {
						q.add (node.getLeft());
					}
					if (node.getRight() != null) {
						q.add (node.getRight());
					}
				}
			}
		}
		System.out.println ();
	}
	
	public BSTNode commonAncestor (BSTNode nodeX, BSTNode nodeY) {
		int x = nodeX.getValue();
		int y = nodeY.getValue();
		BSTNode runningNode = root;
		
		while (runningNode != null) {
			int value = runningNode.getValue();
			if (value > x && value > y) {
				runningNode = runningNode.getLeft();
			} else if (value < x && value < y) {
				runningNode = runningNode.getRight();
			} else {
				return runningNode;
			}
		}
		return null; // if empty tree
	}
}

public class BSTDemo {

	public static void main(String[] args) {

		BST bst = new BST ();
		bst.insert(6);
		bst.insert(2);
		bst.insert(1);
		bst.insert(4);
		bst.insert(3);
		bst.insert(5);
		bst.insert(7);
		
		System.out.print("pre-order: "); bst.preOrder();
		System.out.println();
		System.out.print("breadth first: "); bst.breadthFirst();
		
		System.out.println ("commonAncestor 3 5: " + bst.commonAncestor(new BSTNode (3), new BSTNode (5)).getValue());
		System.out.println ("commonAncestor 3 1: " + bst.commonAncestor(new BSTNode (3), new BSTNode (1)).getValue());
		System.out.println ("commonAncestor 3 7: " + bst.commonAncestor(new BSTNode (3), new BSTNode (7)).getValue());
	}		
}
