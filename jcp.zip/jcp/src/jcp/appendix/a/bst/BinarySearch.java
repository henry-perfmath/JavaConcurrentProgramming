package jcp.appendix.a.bst;

public class BinarySearch {
	public static void main(String[] args) {

		int[] a = { 1, 15, 20, 29, 30, 40, 60 };
		int index = binarySearch(a, 29);
		System.out.println ("index = " + index);
	}

	public static int binarySearch(int[] a, int x) {

		int start = 0;
		int end = a.length - 1;
		int middle = 0;
		
		 while (start <= end) {
			 middle = (start + end) >>>1;
			 if (a[middle] < x) {
				 start = middle + 1;
			 } else if (a[middle] > x) {
				 end = middle -1;
			 } else {
				 return middle;
			 }
		 }
		
		return -1;
	}
}