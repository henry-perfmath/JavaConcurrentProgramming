package jcp.appendix.a.sorting;

import java.util.Collections;
import java.util.Random;
import java.util.ArrayList;

public class QuickSortDemo {
	
	public static int partition(int[] a, int left, int right)
	{
	      int i = left, j = right;
	      int tmp;
	      int pivot = a[(left + right) / 2]; // middle element as the pivot
	     
	      while (i <= j) { //
	            while (a[i] < pivot)
	                  i++; 				// left: found one not smaller than pivot
	            while (a[j] > pivot)
	                  j--; 				// right: found one not larger than pivot
	            if (i <= j) { 			// swap the above two
	                  tmp = a[i];
	                  a[i] = a[j];
	                  a[j] = tmp;
	                  i++;
	                  j--;
	            }
	      }; // loop as long as not done
	     
	      return i;
	}
	 
	public static void quickSort(int[] a, int left, int right) {
	      int pivot = partition(a, left, right);
	      if (left < pivot - 1)
	            quickSort(a, left, pivot - 1);
	      if (pivot < right)
	            quickSort(a, pivot, right);
	}
	
	public static void main(String[] args) {
		final int MAX_ARRAY_SIZE = 10;
		int[] a = new int [MAX_ARRAY_SIZE];
		ArrayList<Integer> al = new ArrayList <Integer>();
		long seed = System.currentTimeMillis();
		Random rnd = new Random (seed);
		for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
			a[i] = (int) (rnd.nextDouble() * MAX_ARRAY_SIZE * 10.0);
			al.add (a[i]);
			System.out.println ("i = " + i + " " + a[i] );
		}
		
		// sort array list
		System.out.println ("sorting using Collections.sort" );
		Collections.sort(al) ;
		
		for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
			System.out.println ("i = " + i + " " + al.get(i));
		}
		
		System.out.println ("sorting using quickSort" );
		quickSort (a, 0, MAX_ARRAY_SIZE - 1);
		for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
			System.out.println ("i = " + i + " " + a[i] );
		}
	}
}
