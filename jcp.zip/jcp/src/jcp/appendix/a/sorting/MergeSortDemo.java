package jcp.appendix.a.sorting;

import java.util.Collections;
import java.util.Random;
import java.util.ArrayList;

public class MergeSortDemo {
	
	public static void merge(int arr[], int left, int mid, int right)
	{
		int[] tempArray = new int [MAX_ARRAY_SIZE];
		int left1 = left;
		int right1 = mid;
		
		int left2 = mid + 1;
		int right2 = right;
		
		int next = left1;
		
		while ((left1 <= right1) && (left2 <= right2)) {
			if (arr [left1] < arr [left2]) {
				tempArray [next] = arr [left1];
				++left1;
			} else {
				tempArray [next] = arr [left2];
				++left2;
			}
			++next;
		}
		
		// finish off the left half if any left using "next"
		for (; left1 <= right1; ++left1, ++next) {
			tempArray [next] = arr [left1];
		}
		
		// finish off the right half if any left
		for (; left2 <= right2; ++left2, ++next) {
			tempArray [next] = arr [left2];
		}
		
		// copy the result back to the original array
		for (next = left; next <= right; ++next) {
			arr [next] = tempArray [next];
		}
	}
	// complexity O(nlog(n))
	public static void mergeSort(int arr[], int left, int right) {
		if (left < right) {
			int mid = (left + right) / 2;
			mergeSort (arr, left, mid); // not mid - 1
			mergeSort (arr, mid + 1, right);
			merge (arr, left, mid, right);
		}
	}
	
	public static final int MAX_ARRAY_SIZE = 10;
	public static void main(String[] args) {

		int[] a = new int [MAX_ARRAY_SIZE];
		ArrayList<Integer> al = new ArrayList <Integer>();
		long seed = System.currentTimeMillis();
		Random rnd = new Random (seed);
		for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
			//a [i] = (int) (Math.random() * MAX_ARRAY_SIZE);
			//a [i] = (int) rnd.nextInt(); ints too large
			a[i] = (int) (rnd.nextDouble() * MAX_ARRAY_SIZE * 10.0);
			al.add (a[i]);
			System.out.println ("i = " + i + " " + a[i] );
		}
		
		// sort array list
		System.out.println ("sorting using Collections.sort" );
		Collections.sort(al) ;
		
		for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
			System.out.println ("i = " + i + " " + al.get(i));
		}
		
		System.out.println ("sorting using quickSort" );
		mergeSort (a, 0, MAX_ARRAY_SIZE - 1);
		for (int i = 0; i < MAX_ARRAY_SIZE; i++) {
			System.out.println ("i = " + i + " " + a[i] );
		}
	}
}
