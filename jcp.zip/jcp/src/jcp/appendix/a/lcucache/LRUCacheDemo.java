/**
 * A doubly-linked list based LRU Cache
 * both get and set are O(1)
 */
package jcp.appendix.a.lcucache;

import java.util.HashMap;

class Node {
	int key;
	String value;
	Node prev;
	Node next;

	public Node(int key, String value) {
		this.key = key;
		this.value = value;
	}
}

class LRUCache {
	int capacity;
	HashMap<Integer, Node> map = new HashMap<Integer, Node>();
	Node head = null;
	Node tail = null;

	public LRUCache(int capacity) {
		this.capacity = capacity;
	}

	public String get(int key) {
		if (map.containsKey(key)) {
			Node node = map.get(key);
			remove(node);
			setHead(node);
			return node.value;
		}

		return "";
	}

	public void remove(Node node) {
		if (node.prev != null) {
			node.prev.next = node.next;
		} else {
			head = node.next;
		}

		if (node.next != null) {
			node.next.prev = node.prev;
		} else {
			tail = node.prev;
		}
	}

	public void setHead(Node node) {
		node.next = head;
		node.prev = null;

		if (head != null) {
			head.prev = node;
		}

		head = node;

		if (tail == null) {
			tail = head;
		}
	}

	public void set(int key, String value) {
		if (map.containsKey(key)) {
			Node currentNode = map.get(key);
			currentNode.value = value;
			remove(currentNode);
			setHead(currentNode);
		} else {
			Node newNode = new Node(key, value);
			if (map.size() >= capacity) {
				map.remove(tail.key);
				remove(tail);
				setHead(newNode);
			} else {
				setHead(newNode);
			}
			map.put(key, newNode);
		}
	}
}

public class LRUCacheDemo {

	public static void main(String[] args) {
		LRUCache cache = new LRUCache(9);

		cache.set(1, "One");
		cache.set(2, "Two");
		cache.set(3, "Three");

		System.out.println(cache.head.value + " ... " + cache.tail.value);

		cache.get(2);
		System.out.println(cache.head.value + " ... " + cache.tail.value);

		cache.get(3);
		System.out.println(cache.head.value + " ... " + cache.tail.value);

		cache.get(1);
		System.out.println(cache.head.value + " ... " + cache.tail.value);
	}

}
