package jcp.ch8.fjframework;

import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

class SumTask extends RecursiveTask<Double> {

	final int THRESHOLD = 2500000;
	final double[] array;
	final int start;
	final int end;

	SumTask(double[] array, int start, int end) {
		this.array = array;
		this.start = start;
		this.end = end;
	}

	SumTask(double[] array) {
		this(array, 0, array.length);
	}

	protected Double compute() {
		double sum = 0.0;
		if (end - start < THRESHOLD)
			for (int i = start; i < end; i++) {
				sum += array[i];
			}
		else {
			int middle = (start + end) >>> 1;
			SumTask sumTask1 = new SumTask(array, start, middle);
			SumTask sumTask2 = new SumTask(array, middle, end);

			sumTask1.fork();
			sumTask2.fork();

			sum = sumTask1.join() + sumTask2.join();
		}

		return sum;
		//return new Double(sum);
	}
}

public class RecursiveTaskDemo {
	public static void main(String[] args) {

		// 1. create a double array
		int ARRAY_SIZE = 10000000;
		double[] doubleArray = new double[ARRAY_SIZE];

		Random random = new Random();
		System.out.println ("A portion of the initial double array");
		for (int i = 0; i < ARRAY_SIZE; i++) {
			doubleArray[i] = random.nextDouble();
			if ((i % ARRAY_SIZE / 10) == 0) {
				System.out.println ("doubleArray[" + i + "] = " + doubleArray[i]);
			}
		}
		
		// 2. create the FJ pool and task object 
		ForkJoinPool forkJoinPool = new ForkJoinPool();
		SumTask task = new SumTask (doubleArray, 0, ARRAY_SIZE);
		
		// 3. start the task
		long startTime = System.currentTimeMillis();
		double totalSum = forkJoinPool.invoke(task);
		long endTime = System.currentTimeMillis();
		System.out.println ("\nElapsed time (ms): " + (endTime - startTime));
		
		// 4. check the result
		System.out.println ("\ntotalSum = " + totalSum);
	}
}
