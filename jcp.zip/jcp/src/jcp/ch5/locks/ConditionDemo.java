package jcp.ch5.locks;

public class ConditionDemo {
	public static void main(String args[]) {
		
		BoundedBuffer boundedBuffer = new BoundedBuffer ();
		new Producer(boundedBuffer);
		new Consumer(boundedBuffer);
	}
}

class Consumer implements Runnable {
	private BoundedBuffer boundedBuffer;

	Consumer(BoundedBuffer boundedBuffer) {
		this.boundedBuffer = boundedBuffer;
		new Thread(this, "Consumer").start();
	}

	public void run() {
		while (true) {
			try {
				int number = (Integer) boundedBuffer.take();
				System.out.println ("consumer got " + number);
			} catch (InterruptedException ie) {
				System.out.println ("consumer interrupted");
			}
		}
	}
}

class Producer implements Runnable {
	BoundedBuffer boundedBuffer;

	Producer(BoundedBuffer boundedBuffer) {
		this.boundedBuffer = boundedBuffer;
		new Thread(this, "Producer").start();
	}

	public void run() {
		int i = 0;

		while (true) {
			try {
			boundedBuffer.put(i++);
			System.out.println ("producer put " + i);
			} catch (InterruptedException ie) {
				System.out.println ("producer interrupted");
			}
		}
	}
}
