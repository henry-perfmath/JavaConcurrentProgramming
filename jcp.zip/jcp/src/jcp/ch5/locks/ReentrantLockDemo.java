package jcp.ch5.locks;

import java.util.concurrent.locks.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ReentrantLockDemo {
	public static void main(String[] args) throws InterruptedException {
		ReentrantLock lock = new ReentrantLock();

		// 1. Create a newFixedThreadPool using the Executors utility class
		ExecutorService executorService = Executors.newFixedThreadPool(100);

		// 2. launch 100 drawers
		for (int i = 0; i < 20; i++) {
			executorService.execute(new Drawer(i, lock));
		}

		// 3. wait 5000 ms for all drawers to complete
		Thread.sleep(5000);
		System.out.println("Number of permits: " + Permit.permits);

		// 4. shut down executorService to avoid resource leak
		executorService.shutdown();
	}
}

// Thread class: a drawer increments/decrements permits if id is even/odd.
class Drawer extends Thread {
	int id;
	ReentrantLock lock;

	Drawer(int id, ReentrantLock lock) {
		this.id = id;
		this.lock = lock;
	}

	public void run() {
		for (int i = 0; i < 10000; i++) {
			if ((this.id % 2) == 0) {
				try {
					lock.lock();
					Permit.permits++;
				} finally {
					lock.unlock();
				}
			} else {
				try {
					lock.lock();
					Permit.permits--;
				} finally {
					lock.unlock();
				}
			}
		}
	}
}

// Shared resource: number of permits
class Permit {
	static int permits = 0;
}
